﻿namespace SimpleMvc.Framework.Contracts
{
    // Returning results from controllers
    public interface IInvocable
    {
        string Invoke();
    }
}
