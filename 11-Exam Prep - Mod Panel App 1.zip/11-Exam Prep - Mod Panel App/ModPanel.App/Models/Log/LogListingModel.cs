﻿namespace ModPanel.App.Models.Log
{
    using Data.Models;

    public class LogListingModel
    {
        public string Admin { get; set; }

        public LogType Type { get; set; }

        public string AdditionalInfo { get; set; }

        public override string ToString()
        {
            string message = null;

            switch (this.Type)
            {
                case LogType.CreatePost:
                    message = $@"created post ""{this.AdditionalInfo}""";
                    break;
                case LogType.EditPost:
                    message = $@"edited post ""{this.AdditionalInfo}""";
                    break;
                case LogType.DeletePost:
                    message = $@"deleted post ""{this.AdditionalInfo}""";
                    break;
                case LogType.UserApproval:
                    message = $"approved the registration of {this.AdditionalInfo}";
                    break;
                case LogType.OpenMenu:
                    message = $"opened {this.AdditionalInfo} Menu";
                    break;
                default: break;
            }

            return $"{this.Admin} {message}";
        }
    }
}
