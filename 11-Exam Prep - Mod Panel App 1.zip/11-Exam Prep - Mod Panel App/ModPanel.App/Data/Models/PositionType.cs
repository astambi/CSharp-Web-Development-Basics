﻿namespace ModPanel.App.Data.Models
{
    public enum PositionType
    {
        Developer = 0,
        Designer = 1,
        TechnicalSupport = 2,
        TechnicalTrainer = 3,
        HR = 4,
        MarketingSpecialist = 5
    }
}
