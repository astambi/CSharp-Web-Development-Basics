﻿namespace ModPanel.App.Models.Posts
{
    public class PostListingModel
    {
        public int Id { get; set; }

        public string Title { get; set; }
    }
}
