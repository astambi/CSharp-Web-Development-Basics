﻿namespace WebServer.Server.Contracts
{
    public interface IView
    {
        string View();
    }
}