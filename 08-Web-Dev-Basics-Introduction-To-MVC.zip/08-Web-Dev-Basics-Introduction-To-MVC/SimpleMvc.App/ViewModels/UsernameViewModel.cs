﻿namespace SimpleMvc.App.ViewModels
{
    public class UsernameViewModel
    {
        public int UserId { get; set; }

        public string Username { get; set; }
    }
}
