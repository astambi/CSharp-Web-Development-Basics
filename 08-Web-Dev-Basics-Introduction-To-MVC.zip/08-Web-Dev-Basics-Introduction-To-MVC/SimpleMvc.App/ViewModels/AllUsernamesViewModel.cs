﻿namespace SimpleMvc.App.ViewModels
{
    using System.Collections.Generic;

    public class AllUsernamesViewModel
    {
        public IList<UsernameViewModel> UsernamesWithIds { get; set; }
    }
}
