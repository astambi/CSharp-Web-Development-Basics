﻿namespace WebServer.Server.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}