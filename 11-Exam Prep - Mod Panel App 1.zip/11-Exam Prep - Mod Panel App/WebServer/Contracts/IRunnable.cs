﻿namespace WebServer.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
