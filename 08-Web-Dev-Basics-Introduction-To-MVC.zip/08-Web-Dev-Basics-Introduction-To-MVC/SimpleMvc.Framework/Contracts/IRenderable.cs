﻿namespace SimpleMvc.Framework.Contracts
{
    // Rendering HTML views
    public interface IRenderable
    {
        string Render();
    }
}
