﻿namespace WebServer.Server.Enums
{
    public enum HttpRequestMethod
    {
        Get,
        Post
    }
}