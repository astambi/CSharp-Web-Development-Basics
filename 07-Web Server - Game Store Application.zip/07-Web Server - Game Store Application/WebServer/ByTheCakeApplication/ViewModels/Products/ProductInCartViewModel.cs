﻿namespace WebServer.ByTheCakeApplication.ViewModels.Products
{
    public class ProductInCartViewModel
    {
        public string Name { get; set; }

        public decimal Price { get; set; }
    }
}
